@extends('layoutPersonalIPE')
@section('content')
    <div class="mt-3 text-center">
        <h3>Documentos Registrados</h2>
    </div>
    <ul class="nav nav-tabs mt-3 mb-3" id="pills-tab" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home" aria-selected="true">Generados internamente</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">Recibidos externos</button>
        </li>
       
    </ul>
    <div class="tab-content" id="pills-tabContent">
        <div class="container tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab" tabindex="0">
            <div class="navbar">
                <div>
                    <h5 class="mb-3 d-flex">Documentos enviados</h4> 
                </div>
                <div class="d-flex">
                    <a id="btnRegistrar" class="btn btn-primary d-flex" href="cargarRegistrarDocumentoEnviado">Registrar nuevo</a>
                </div>
            </div>
            <div class="scrollable">
                <style>
                    .scrollable{
                        height: 400px;
                        overflow: scroll;
                    }
                </style>
                <table id="tableEnviados" class="table table-light table-striped text-center">
                    <thead>
                        <tr>
                        <th scope="col">Semáforo</th>
                        <th scope="col">Fecha</th>
                        <th scope="col">Número documento</th>
                        <th scope="col">Asunto</th>
                        <th scope="col">¿Respuesta?</th>
                        <th scope="col">Antecedente</th>
                        <th scope="col">Precedente</th>
                        <th scope="col">estatus</th>
                        <th scope="col">Detalle</th>
                        </tr>
                    </thead>
                    <tbody>
                        
                        @foreach($enviado as $env)
                            <tr>
                                <td>...</td>
                                <td>{{$env->fechaCreacion}}</td>
                                <td>{{$env->numeroDocumento}}</td>
                                <td>{{$env->asunto}}</td>
                                <td>{{$env->estatusRespuesta}}</td>
                                <td>{{$env->documentoAntecedente}}</td>
                                <td>{{$env->documentoPrecedente}}</td>
                                <td>{{$env->estatus}}</td>
                                <td><a href="{{url ('verDetalleDocumentoEnviado', $env->id)}}" class="btn btn-primary">Ver detalle</a></td>
                            </tr> 
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
        <div class="container tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab" tabindex="0">
            <div class="navbar">
                <div>
                    <h5 class="mb-3 d-flex">Documentos recibidos</h4> 
                </div>
                <div class="d-flex">
                    <a id="btnRegistrar" class="btn btn-primary d-flex" href="cargarRegistrarDocumentoRecibido">Registrar nuevo</a>
                </div>
            </div>
            <div class="scrollable">
                <table table="tableRecibidos" class="table table-light table-striped text-center">
                    <thead>
                        <tr>
                        <th scope="col">Semáforo</th>
                        <th scope="col">Fecha</th>
                        <th scope="col">Número documento</th>
                        <th scope="col">Asunto</th>
                        <th scope="col">¿Respuesta?</th>
                        <th scope="col">Antecedente</th>
                        <th scope="col">Precedente</th>
                        <th scope="col">Estatus</th>
                        <th scope="col">Detalle</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($recibido as $rec)
                            <tr>
                                <td>...</td>
                                <td>{{$rec->fechaCreacion}}</td>
                                <td>{{$rec->numeroDocumento}}</td>
                                <td>{{$rec->asunto}}</td>
                                <td>{{$rec->estatusRespuesta}}</td>
                                <td>{{$rec->documentoAntecedente}}</td>
                                <td>{{$rec->documentoPrecedente}}</td>
                                <td>{{$rec->estatus}}</td>
                                <td><a href="{{url ('verDetalleDocumentoRecibido', $rec->id)}}" class="btn btn-primary">Ver detalle</a></td>
                            </tr> 
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
        </div>
    </div> 
@endsection   
