@extends('layoutAdministrador')
@section('content')
    <div class="container mt-3">
        <form class="form-control" action="{{url ('editarArea', $informacionArea->id)}}" method="POST">
            @csrf
            @method("PUT")
            <p class="fs-2 text-center">Editar Área</p>
            <div class="mb-3 mt-2">
                <label for="nombreArea" class="form-label">Nombre del área:</label>
                <input class="form-control" type="text" id="nombreArea" name="nombreArea" value="{{$informacionArea->nombreArea}}" required>
            </div>
            <div class="mb-2">
                <label for="tipoArea" class="form-label">Seleccione el tipo de área:</label>
                <select name="tipoArea" id="tipoArea" class="form-select" required>
                    <option selected="true">{{$informacionArea->tipoArea}}</option>
                    <option value="Departamento">Departamento</option>
                    <option value="Oficina">Oficina</option>
                    <option value="Área">Área</option>
                </select>
            </div>
            <div class="mb-2">
                <label for="perteneceA" class="form-label">Seleccione el área a la cuál pertenece:</label>
                <select name="perteneceA" id="perteneceA" class="form-select">
                    <option selected="true">{{$informacionArea->perteneceA}}</option>
                    @foreach($areas as $area)
                    <option value="{{$area->nombreArea}}">{{$area->tipoArea}} {{$area->nombreArea}}</option>
                    @endforeach
                </select>
            </div>
            <div class="d-grid gap-2 col-3 mx-auto">
                <input id="btnRegistrar" class="btn btn-success" type="submit" value="Guardar">
            </div>          
        </form>
    </div>
@endsection