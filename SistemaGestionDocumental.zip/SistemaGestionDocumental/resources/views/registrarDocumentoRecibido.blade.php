@extends('layoutPersonalIPE')
@section('content')
<div class="container mt-3">
        <form class="form-control" action="registrarDocumentoRecibido" method="POST">
            @csrf
            <p class="fs-2 text-center">Registrar documento recibido</p>
            <div class="row g-3 align-items-center">
                <div class="col-4">
                    <div class="mb-2 mt-2">
                        <label for="numeroDocumento" class="form-label">Número de documento:</label>
                        <input class="form-control" type="text" id="numeroDocumento" name="numeroDocumento" required>
                    </div>
                    <div class="mb-2">
                        <label for="tipoDocumento" class="form-label">Tipo de documento:</label>
                        <select name="tipoDocumento" id="tipoDocumento" class="form-select" required>
                            <option selected="true" disabled="disabled">Abra este menú</option>
                            <option value="Memorandum">Memorandum</option>
                            <option value="Oficio">Oficio</option>
                            <option value="Invitación">Invitación</option>
                            <option value="Recordatorio">Recordatorio</option>
                            <option value="Recordatorio">Otro</option>
                        </select>
                    </div>
                    <div class="mb-2">
                        <label for="asunto" class="form-label">Asunto:</label>
                        <textarea class="form-control" name="asunto" id="asunto" aria-label="With textarea" required></textarea>
                    </div>
                    <div class="mb-2">
                        <label for="documentoAntecedente" class="form-label">Documento antecedente:</label>
                        <input class="form-control" type="text" id="documentoAntecedente" name="documentoAntecedente">
                    </div>
                    <div class="mb-2">
                        <label for="documentoPrecedente" class="form-label">Documento precedente:</label>
                        <input class="form-control" type="text" id="documentoPrecedente" name="documentoPrecedente">
                    </div>
                </div>
                <div class="col-4">
                    <div class="mb-2">
                        <label for="estatusRespuesta" class="form-label">¿Espera respuesta?</label>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="estatusRespuesta" id="estatusRespuesta1" value="Sí">
                            <label class="form-check-label" for="estatusRespuesta1">
                                Sí
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="estatusRespuesta" id="estatusRespuesta2" value="No">
                            <label class="form-check-label" for="estatusRespuesta2">
                                No
                            </label>
                        </div>
                    </div>
                    <div class="mb-2">
                        <label for="diasRespuesta" class="form-label">Días de respuesta:</label>
                        <input class="form-control" type="number" id="diasRespuesta" name="diasRespuesta">
                    </div>
                    <div class="mb-2">
                        <label for="quienResponde" class="form-label">¿Quién responde?</label>
                        <input class="form-control" type="text" id="quienResponde" name="quienResponde">
                    </div>
                    <div class="mb-2">
                        <label for="fechaCreacion" class="form-label">Fecha de registro:</label>
                        <input class="form-control" type="date" id="fechaCreacion" name="fechaCreacion">
                    </div>
                    <div class="mb-2">
                        <label for="comentarios" class="form-label">Comentarios:</label>
                        <textarea class="form-control" name="comentarios" id="comentarios" aria-label="With textarea"></textarea>
                    </div>
                </div>
                <div class="col-4">
                    <style>
                        .scrollable{
                            height: 170px;
                            overflow: scroll;
                        }
                    </style>

                    <label for="enviarA" class="form-label">Enviar a:</label>
                    <div class="scrollable mb-2" id="enviarA">
                        @foreach($areas as $area)
                            <div class="form-check">
                                
                                <label for="envio" class="form-check-label">
                                    <input type="checkbox" class="form-check-input" id="envio" name="checkEnviado[]" value="{{$area->nombreArea}}" >
                                    {{$area->tipoArea}} de {{$area->nombreArea}}
                                </label>
                            </div>
                        @endforeach
                    </div>

                    <label for="copiaA" class="form-label">Copia a:</label>
                    <div class="scrollable" id="copiaA">
                        @foreach($areas as $area)
                            <div class="form-check">
                                
                                <label for="copia" class="form-check-label">
                                    <input type="checkbox" class="form-check-input" id="copia" name="checkCopia[]" value="{{$area->nombreArea}}" >
                                    {{$area->tipoArea}} de {{$area->nombreArea}}
                                </label>
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>
            
            <div class="d-grid gap-2 col-3 mx-auto mt-3">
                <input id="btnRegistrar" class="btn btn-success" type="submit" value="Registrar">
            </div>          
        </form>
    </div>
@endsection