@extends('layoutAdministrador')
@section('content')
    <div class="container">
        <div class="mt-3 text-center">
            <h3>Áreas Registradas</h2>
        </div>
        <div class="divBtnRegistrar">
            <a href="formularioRegistroArea" id="btnRegistrar" class="btn btn-primary mb-3">Registrar nuevo</a>
        </div>

        <div class="scrollable">
            <style>
                .scrollable{
                    height: 400px;
                    overflow: scroll;
                }
                #btnModal{
                    background: #7A6F44;
                    border: #7A6F44;
                }
            </style>
            <table id="tableEnviados" class="table table-light table-striped text-center">
                <thead>
                    <tr>
                    <th scope="col">Nombre de área</th>
                    <th scope="col">Tipo de área</th>
                    <th scope="col">Pertenece a</th>
                    <th scope="col">Opciones</th>
                    </tr>
                </thead>
                <tbody>
                   @foreach($areas as $area)
                    <tr>
                        <td>{{$area->nombreArea}}</td>
                        <td>{{$area->tipoArea}}</td>
                        <td>{{$area->perteneceA}}</td>
                        <td>
                            <a class="btn btn-warning" href="{{url ('llenarEdicionArea', $area->id)}}"> 
                                <img src="https://cdn-icons-png.flaticon.com/512/1159/1159633.png" alt="Bootstrap" width="18" height="14">
                            </a> 
                            <a class="btn btn-danger" href="{{url ('eliminarArea', $area->id)}}" method="delete">
                                <img src="https://www.pngplay.com/wp-content/uploads/7/Delete-Logo-PNG-HD-Quality.png" alt="Bootstrap" width="18" height="14">
                            </a>
                        </td>
                    </tr>
                   @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection