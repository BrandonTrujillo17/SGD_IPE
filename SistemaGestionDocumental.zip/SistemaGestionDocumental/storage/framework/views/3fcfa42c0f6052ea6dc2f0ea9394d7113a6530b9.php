<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Gestión Documental</title>
    <?php echo notifyCss(); ?>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
    
</head>
<body>
    <style>
        #navbar1{
            background: #7A6F44;
            font-size: 20px;
        }
        #btnRegistrar{
            background: #7A6F44;
            border: #7A6F44;
            
        }
        .divBtnRegistrar{
            text-align: right;
        }
    </style>
    <nav id="navbar1" class="navbar">
        <div class="container-fluid">
            <a class="navbar-brand text-light fw-bold">Sistema de Gestión Documental</a>
            <ul class="nav nav-bar d-flex">
                <li class="nav-item">
                    <a class="nav-link active text-light" aria-current="page" href="http://localhost/SistemaGestionDocumental/public/usuarios">Usuarios</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active text-light" aria-current="page" href="http://localhost/SistemaGestionDocumental/public/areas">Áreas</a>
                </li>
                <li class="nav-item">
                    <a class="navbar-brand" href="http://localhost/SistemaGestionDocumental/public/">
                        <img src="https://static-00.iconduck.com/assets.00/logout-icon-512x512-2x08s84n.png" alt="Bootstrap" width="30" height="24">
                    </a>
                </li>
            </ul>
        </div>
    </nav>
    <?php echo $__env->yieldContent('content'); ?>

    <?php echo notifyJs(); ?>
    <?php if (isset($component)) { $__componentOriginalf6d1e1ab7a8df2de5d0bdc28df8775f180a35b0c = $component; } ?>
<?php $component = $__env->getContainer()->make(Mckenziearts\Notify\NotifyComponent::class, []); ?>
<?php $component->withName('notify-messages'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf6d1e1ab7a8df2de5d0bdc28df8775f180a35b0c)): ?>
<?php $component = $__componentOriginalf6d1e1ab7a8df2de5d0bdc28df8775f180a35b0c; ?>
<?php unset($__componentOriginalf6d1e1ab7a8df2de5d0bdc28df8775f180a35b0c); ?>
<?php endif; ?>
</body>
</html><?php /**PATH C:\Users\brand\Documents\xampp\htdocs\SistemaGestionDocumental\resources\views/layoutAdministrador.blade.php ENDPATH**/ ?>