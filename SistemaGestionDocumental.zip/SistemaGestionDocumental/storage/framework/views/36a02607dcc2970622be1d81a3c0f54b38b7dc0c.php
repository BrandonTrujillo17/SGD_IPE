
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="mt-3 text-center">
            <h3>Usuarios Registrados</h2>
        </div>
        <div class="divBtnRegistrar">
            <a href="formularioRegistroUsuario" id="btnRegistrar" class="btn btn-primary mb-3">Registrar nuevo</a>
        </div>

        <div class="scrollable">
            <style>
                .scrollable{
                    height: 400px;
                    overflow: scroll;
                }
                #btnModal{
                    background: #7A6F44;
                    border: #7A6F44;
                }
            </style>
            <table id="tableEnviados" class="table table-light table-striped text-center">
                <thead>
                    <tr>
                    <th scope="col">No. Personal</th>
                    <th scope="col">Nombre</th>
                    <th scope="col">Usuario</th>
                    <th scope="col">rol</th>
                    <th scope="col">Pertenece a:</th>
                    <th scope="col">Opciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $usuario; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($user->numeroPersonal); ?></td>
                            <td><?php echo e($user->nombre); ?></td>
                            <td><?php echo e($user->usuario); ?></td>
                            <td><?php echo e($user->rol); ?></td>
                            <td><?php echo e($user->perteneceA); ?></td>
                            <td>
                                <a class="btn btn-warning" href="<?php echo e(url ('llenarEdicionUsuario', $user->id)); ?>"> 
                                    <img src="https://cdn-icons-png.flaticon.com/512/1159/1159633.png" alt="Bootstrap" width="18" height="14">
                                </a> 
                                <a class="btn btn-danger" href="<?php echo e(url ('eliminarUsuario', $user->id)); ?>" method="delete">
                                    <img src="https://www.pngplay.com/wp-content/uploads/7/Delete-Logo-PNG-HD-Quality.png" alt="Bootstrap" width="18" height="14">
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutAdministrador', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\brand\Documents\xampp\htdocs\SistemaGestionDocumental\resources\views/usuarios.blade.php ENDPATH**/ ?>