
<?php $__env->startSection('content'); ?>
    <div class="container mt-3">
        <form class="form-control" action="registrarUsuario" method="POST">
            <?php echo csrf_field(); ?>
            <p class="fs-2 text-center">Registrar Usuario</p>
            <div class="mb-3 mt-2">
                <label for="noPersonal" class="form-label">Número de Personal:</label>
                <input class="form-control" type="text" id="noPersonal" name="noPersonal" required>
            </div>
            <div class="mb-2">
                <label for="nombre" class="form-label">Nombre:</label>
                <input class="form-control" type="text" id="nombre" name="nombre" required>
            </div>
            <div class="mb-2">
                <label for="usuario" class="form-label">Usuario:</label>
                <input class="form-control" type="text" id="usuario" name="usuario" required>
            </div>           
            <div class="mb-2">
                <label for="contraseña" class="form-label">Contraseña:</label>
                <input type="password" class="form-control" id="contraseña" name="contraseña" required>
            </div>
            <div class="mb-2">
                <label for="rol" class="form-label">Seleccione el rol:</label>
                <select name="rol" id="rol" class="form-select" required>
                    <option selected="true" disabled="disabled">Abra este menú</option>
                    <option value="PersonalIPE">Personal IPE</option>
                    <option value="Administrador">Administrador</option>
                    <option value="Subdirector">Subdirector</option>
                </select>
            </div>
            <div class="mb-2">
                <label for="perteneceA" class="form-label">Seleccione el área:</label>
                <select name="perteneceA" id="perteneceA" class="form-select">
                    <option selected="true" disabled="disabled">Abra este menú</option>
                    <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($area->nombreArea); ?>"><?php echo e($area->tipoArea); ?> <?php echo e($area->nombreArea); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="d-grid gap-2 col-3 mx-auto">
                <input id="btnRegistrar" class="btn btn-success" type="submit" value="Registrar">
            </div>          
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutAdministrador', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\brand\Documents\xampp\htdocs\SistemaGestionDocumental\resources\views/registrarUsuario.blade.php ENDPATH**/ ?>