
<?php $__env->startSection('content'); ?>
    <div class="mt-3 text-center">
        <h3>Documentos Registrados</h2>
    </div>
    <ul class="nav nav-tabs mt-3 mb-3" id="pills-tab" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home" aria-selected="true">Generados internamente</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">Recibidos externos</button>
        </li>
       
    </ul>
    <div class="tab-content" id="pills-tabContent">
        <div class="container tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab" tabindex="0">
            <div class="navbar">
                <div>
                    <h5 class="mb-3 d-flex">Documentos enviados</h4> 
                </div>
                <div class="d-flex">
                    <a id="btnRegistrar" class="btn btn-primary d-flex" href="cargarRegistrarDocumentoEnviado">Registrar nuevo</a>
                </div>
            </div>
            <div class="scrollable">
                <style>
                    .scrollable{
                        height: 400px;
                        overflow: scroll;
                    }
                </style>
                <table id="tableEnviados" class="table table-light table-striped text-center">
                    <thead>
                        <tr>
                        <th scope="col">Semáforo</th>
                        <th scope="col">Fecha</th>
                        <th scope="col">Número documento</th>
                        <th scope="col">Asunto</th>
                        <th scope="col">¿Respuesta?</th>
                        <th scope="col">Antecedente</th>
                        <th scope="col">Precedente</th>
                        <th scope="col">estatus</th>
                        <th scope="col">Detalle</th>
                        </tr>
                    </thead>
                    <tbody>
                        
                        <?php $__currentLoopData = $enviado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $env): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>...</td>
                                <td><?php echo e($env->fechaCreacion); ?></td>
                                <td><?php echo e($env->numeroDocumento); ?></td>
                                <td><?php echo e($env->asunto); ?></td>
                                <td><?php echo e($env->estatusRespuesta); ?></td>
                                <td><?php echo e($env->documentoAntecedente); ?></td>
                                <td><?php echo e($env->documentoPrecedente); ?></td>
                                <td><?php echo e($env->estatus); ?></td>
                                <td><a href="<?php echo e(url ('verDetalleDocumentoEnviado', $env->id)); ?>" class="btn btn-primary">Ver detalle</a></td>
                            </tr> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="container tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab" tabindex="0">
            <div class="navbar">
                <div>
                    <h5 class="mb-3 d-flex">Documentos recibidos</h4> 
                </div>
                <div class="d-flex">
                    <a id="btnRegistrar" class="btn btn-primary d-flex" href="cargarRegistrarDocumentoRecibido">Registrar nuevo</a>
                </div>
            </div>
            <div class="scrollable">
                <table table="tableRecibidos" class="table table-light table-striped text-center">
                    <thead>
                        <tr>
                        <th scope="col">Semáforo</th>
                        <th scope="col">Fecha</th>
                        <th scope="col">Número documento</th>
                        <th scope="col">Asunto</th>
                        <th scope="col">¿Respuesta?</th>
                        <th scope="col">Antecedente</th>
                        <th scope="col">Precedente</th>
                        <th scope="col">Estatus</th>
                        <th scope="col">Detalle</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $recibido; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>...</td>
                                <td><?php echo e($rec->fechaCreacion); ?></td>
                                <td><?php echo e($rec->numeroDocumento); ?></td>
                                <td><?php echo e($rec->asunto); ?></td>
                                <td><?php echo e($rec->estatusRespuesta); ?></td>
                                <td><?php echo e($rec->documentoAntecedente); ?></td>
                                <td><?php echo e($rec->documentoPrecedente); ?></td>
                                <td><?php echo e($rec->estatus); ?></td>
                                <td><a href="<?php echo e(url ('verDetalleDocumentoRecibido', $rec->id)); ?>" class="btn btn-primary">Ver detalle</a></td>
                            </tr> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        </div>
    </div> 
<?php $__env->stopSection(); ?>   

<?php echo $__env->make('layoutPersonalIPE', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\brand\Documents\xampp\htdocs\SistemaGestionDocumental\resources\views/principalPersonalIPE.blade.php ENDPATH**/ ?>