
<?php $__env->startSection('content'); ?>
    <div class="container mt-3">
        <form class="form-control" action="registrarArea" method="POST">
            <?php echo csrf_field(); ?>
            <p class="fs-2 text-center">Registrar Área</p>
            <div class="mb-3 mt-2">
                <label for="nombreArea" class="form-label">Nombre del área:</label>
                <input class="form-control" type="text" id="nombreArea" name="nombreArea" placeholder="Gobierno Electrónico" required>
            </div>
            <div class="mb-2">
                <label for="tipoArea" class="form-label">Seleccione el tipo de área:</label>
                <select name="tipoArea" id="tipoArea" class="form-select" required>
                    <option selected="true" disabled="disabled">Abra este menú</option>
                    <option value="Departamento">Departamento</option>
                    <option value="Oficina">Oficina</option>
                    <option value="Área">Área</option>
                </select>
            </div>
            <div class="mb-2">
                <label for="perteneceA" class="form-label">Seleccione el área a la cuál pertenece:</label>
                <select name="perteneceA" id="perteneceA" class="form-select">
                    <option selected="true" disabled="disabled">Abra este menú</option>
                    <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($area->nombreArea); ?>"><?php echo e($area->tipoArea); ?> <?php echo e($area->nombreArea); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="d-grid gap-2 col-3 mx-auto">
                <input id="btnRegistrar" class="btn btn-success" type="submit" value="Registrar">
            </div>          
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutAdministrador', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\brand\Documents\xampp\htdocs\SistemaGestionDocumental\resources\views/registrarArea.blade.php ENDPATH**/ ?>