
<?php $__env->startSection('content'); ?>
<div class="container mt-3">
        <form class="form-control" action="<?php echo e(url ('guardarCambiosDetalleDocumentoEnviado', $informacionDocumento->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field("PUT"); ?>
            <p class="fs-2 text-center">Detalle de documento enviado</p>
            <div class="row g-3 align-items-center">
                <div class="col-3">
                    <div class="mb-2 mt-2">
                        <label for="numeroDocumento" class="form-label">Número de documento:</label>
                        <input class="form-control" type="text" id="numeroDocumento" name="numeroDocumento" value="<?php echo e($informacionDocumento->numeroDocumento); ?>" readonly>
                    </div>
                    <div class="mb-2">
                        <label for="tipoDocumento" class="form-label">Tipo de documento:</label>
                        <input class="form-control" type="text" id="tipoDocumento" name="tipoDocumento" value="<?php echo e($informacionDocumento->tipoDocumento); ?>" readonly>
                    </div>
                    <div class="mb-2">
                        <label for="asunto" class="form-label">Asunto:</label>
                        <textarea class="form-control" name="asunto" id="asunto" aria-label="With textarea" value="<?php echo e($informacionDocumento->asunto); ?>" readonly><?php echo e($informacionDocumento->asunto); ?></textarea>
                    </div>
                    <div class="mb-2">
                        <label for="documentoAntecedente" class="form-label">Documento antecedente:</label>
                        <input class="form-control" type="text" id="documentoAntecedente" name="documentoAntecedente" value="<?php echo e($informacionDocumento->documentoAntecedente); ?>" readonly>
                    </div>
                    <div class="mb-2">
                        <label for="documentoPrecedente" class="form-label">Documento precedente:</label>
                        <input class="form-control" type="text" id="documentoPrecedente" name="documentoPrecedente" value="<?php echo e($informacionDocumento->documentoPrecedente); ?>" readonly>
                    </div>
                    <div class="mb-2">
                        <label for="comentarios" class="form-label">Comentarios:</label>
                        <textarea class="form-control" name="comentarios" id="comentarios" aria-label="With textarea" value="<?php echo e($informacionDocumento->comentarios); ?>"><?php echo e($informacionDocumento->comentarios); ?></textarea>
                    </div>
                </div>
                <div class="col-4">
                    <div class="mb-2">
                        <?php if($informacionDocumento->estatusRespuesta == "Sí"): ?>
                            <label for="estatusRespuesta" class="form-label">¿Espera respuesta?</label>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="estatusRespuesta" id="estatusRespuesta1" value="Sí" checked disabled>
                                <label class="form-check-label" for="estatusRespuesta1">
                                    Sí
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="estatusRespuesta" id="estatusRespuesta2" value="No" disabled>
                                <label class="form-check-label" for="estatusRespuesta2">
                                    No
                                </label>
                            </div>
                            <?php if($informacionDocumento->diasRespuesta != null): ?>
                                <div class="mb-2">
                                    <label for="diasRespuesta" class="form-label">Días de respuesta:</label>
                                    <input class="form-control" type="number" id="diasRespuesta" name="diasRespuesta" value="<?php echo e($informacionDocumento->diasRespuesta); ?>" disabled>
                                </div>
                            <?php endif; ?>
                            <?php if($informacionDocumento->diasRespuesta == null): ?>
                                <div class="mb-2">
                                    <label for="diasRespuesta" class="form-label">Días de respuesta:</label>
                                    <input class="form-control" type="number" id="diasRespuesta" name="diasRespuesta">
                                </div>
                            <?php endif; ?>
                            <?php if($informacionDocumento->quienResponde != null): ?>
                                <div class="mb-2">
                                    <label for="quienResponde" class="form-label">¿Quién responde?</label>
                                    <input class="form-control" type="text" id="quienResponde" name="quienResponde" value="<?php echo e($informacionDocumento->quienResponde); ?>" disabled>
                                </div>
                            <?php endif; ?>
                            <?php if($informacionDocumento->quienResponde == null): ?>
                                <div class="mb-2">
                                    <label for="quienResponde" class="form-label">¿Quién responde?</label>
                                    <input class="form-control" type="text" id="quienResponde" name="quienResponde">
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                        <?php if($informacionDocumento->estatusRespuesta == "No"): ?>
                            <label for="estatusRespuesta" class="form-label">¿Espera respuesta?</label>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="estatusRespuesta" id="estatusRespuesta1" value="Sí" disabled>
                                <label class="form-check-label" for="estatusRespuesta1">
                                    Sí
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="estatusRespuesta" id="estatusRespuesta2" value="No" checked disabled>
                                <label class="form-check-label" for="estatusRespuesta2">
                                    No
                                </label>
                            </div>
                            <div class="mb-2">
                                <label for="diasRespuesta" class="form-label">Días de respuesta:</label>
                                <input class="form-control" type="number" id="diasRespuesta" name="diasRespuesta" disabled>
                            </div>
                            <div class="mb-2">
                                <label for="quienResponde" class="form-label">¿Quién responde?</label>
                                <input class="form-control" type="text" id="quienResponde" name="quienResponde" disabled>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="mb-2">
                        <label for="fechaCreacion" class="form-label">Fecha de registro:</label>
                        <input class="form-control" type="text" id="fechaCreacion" name="fechaCreacion" value="<?php echo e($informacionDocumento->fechaCreacion); ?>" readonly>
                    </div>
                    <div class="mb-2">
                        <label for="" class="form-label">Semáforo de respuesta:</label>
                    </div>
                    <?php if($informacionDocumento->estatus == "Enviado"): ?>
                        <div class="mb-2">
                            <label for="estatus" class="form-label">Estatus:</label>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="estatus" id="estatus1" value="Enviado" checked>
                                <label class="form-check-label" for="estatus1">
                                    Enviado
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="estatus" id="estatus2" value="En revisión">
                                <label class="form-check-label" for="estatus2">
                                    En revisión
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="estatus" id="estatus3" value="Finalizado">
                                <label class="form-check-label" for="estatus3">
                                    Finalizado
                                </label>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if($informacionDocumento->estatus == "En revisión"): ?>
                        <div class="mb-2">
                            <label for="estatus" class="form-label">Estatus:</label>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="estatus" id="estatus1" value="enviado">
                                <label class="form-check-label" for="estatus1">
                                    Enviado
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="estatus" id="estatus2" value="En revisión" checked>
                                <label class="form-check-label" for="estatus2">
                                    En revisión
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="estatus" id="estatus3" value="Finalizado">
                                <label class="form-check-label" for="estatus3">
                                    Finalizado
                                </label>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if($informacionDocumento->estatus == "Finalizado"): ?>
                        <div class="mb-2">
                            <label for="estatus" class="form-label">Estatus:</label>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="estatus" id="estatus1" value="Enviado">
                                <label class="form-check-label" for="estatus1">
                                    Enviado
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="estatus" id="estatus2" value="En revisión">
                                <label class="form-check-label" for="estatus2">
                                    En revisión
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="estatus" id="estatus3" value="Finalizado" checked>
                                <label class="form-check-label" for="estatus3">
                                    Finalizado
                                </label>
                            </div>
                        </div>
                    <?php endif; ?>

                </div>
                
                <div class="col-5">
                    <style>
                        .scrollable{
                            height: 170px;
                            overflow: scroll;
                        }
                        .btn.btn-primary{
                            background: #7A6F44;
                            border: #7A6F44;
                        }
                    </style>
                    <label for="enviarA" class="form-label">Enviar a:</label>
                    <div class="scrollable mb-2" id="enviadoA">
                        <?php $__currentLoopData = $informacionEnvio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $envio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($envio->recibido == "Sí"): ?>
                                <div class="row g-3 align-items-center">
                                    <div class="col-6">
                                        <div class="form-check">
                                            <label for="checkRespuestaEnviado[]" class="form-check-label">
                                                <input type="checkbox" class="form-check-input" id="envio" name="checkRespuestaEnviado[]" value="<?php echo e($envio->nombreArea); ?>" checked disabled>
                                                    <?php echo e($envio->nombreArea); ?>

                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-5">
                                        <div class="mb-2">
                                            <input class="form-control" type="text" value="<?php echo e($envio->fechaHoraRecepcion); ?>" readonly>
                                        </div>
                                    </div>
                                </div> 
                            <?php endif; ?>
                            <?php if($envio->recibido == null): ?>
                                <div class="form-check">
                                    <label for="checkRespuestaEnviado[]" class="form-check-label">
                                        <input type="checkbox" class="form-check-input" id="envio" name="checkRespuestaEnviado[]" value="<?php echo e($envio->nombreArea); ?>" >
                                            <?php echo e($envio->nombreArea); ?>

                                    </label>
                                </div> 
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <label for="copiaA" class="form-label">Copia a:</label>
                    <div class="scrollable" id="copiadoA">
                        <?php $__currentLoopData = $informacionCopia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $copia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($copia->recibido == "Sí"): ?>
                                <div class="row g-3 align-items-center">
                                    <div class="col-6">
                                        <div class="form-check">
                                            <label for="checkRespuestaCopia[]" class="form-check-label">
                                                <input type="checkbox" class="form-check-input" id="copia" name="checkRespuestaCopia[]" value="<?php echo e($copia->nombreArea); ?>" checked disabled>
                                                    <?php echo e($copia->nombreArea); ?>

                                                </label>
                                        </div>
                                    </div>
                                    <div class="col-5">
                                        <div class="mb-2">
                                            <input class="form-control" type="text" value="<?php echo e($copia->fechaHoraRecepcion); ?>" readonly>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <?php if($copia->recibido == null): ?>
                                <div class="form-check">
                                    <label for="checkRespuestaCopia[]" class="form-check-label">
                                        <input type="checkbox" class="form-check-input" id="copia" name="checkRespuestaCopia[]" value="<?php echo e($copia->nombreArea); ?>" >
                                            <?php echo e($copia->nombreArea); ?>

                                    </label>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <div class="d-grid gap-2 col-2 mx-auto mt-3">
                <input class="btn btn-primary" type="submit" value="Guardar cambios">
            </div>         
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutPersonalIPE', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\brand\Documents\xampp\htdocs\SistemaGestionDocumental\resources\views/detalleDocumentoEnviado.blade.php ENDPATH**/ ?>