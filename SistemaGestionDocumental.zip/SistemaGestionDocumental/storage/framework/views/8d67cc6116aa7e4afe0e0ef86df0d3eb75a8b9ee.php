<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio de Sesión</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
    <?php echo notifyCss(); ?>
</head>
<body>
    <style>
        body{
            background: #7A6F44
        }
        #form{
            box-shadow: 13px 13px 30px #3B351F;
        }
        #btnLogin{
            box-shadow: 4px 4px 10px #7D7D7D;
            background: #7A6F44;
            border: #7A6F44;
        }
        #usuario{
            box-shadow: -2px -2px 5px #A4A4A3 inset;
        }
        #contraseña{
            box-shadow: -2px -2px 5px #A4A4A3 inset;
        }
    </style>
    <div class="container mt-5 form-field d-flex align-items-center d-grid col-4 mx-auto">
        <form id="form" action="" class="form-control mt-3 ">
        <div class="text-center mt-5 name">
            <p class="fs-2">
                Sistema de Gestión Documental
            </p>    
        </div>
        <?php echo csrf_field(); ?>
            <div class="mb-3 mt-3 text-center mt-4">
                <label  class="form-label" for="usuario">Usuario:</label>
                <input class="form-control text-center" type="text" id="usuario" name="usuario" placeholder="Ingrese su nombre de usuario:" required>
            </div>
            <div class="mb-3 text-center mt-4">
                <label  class="form-label" for="contraseña">Contraseña:</label>
                <input class="form-control text-center" type="password" id="contraseña" name="contraseña" placeholder="Ingrese su contraseña:" required>
            </div>
            <div class="mb-3 d-grid gap-2 col-3 mx-auto">
                <input id="btnLogin" type="submit" class="btn btn-primary " value="Iniciar Sesión">
            </div>
        </form>
    </div>

    
    <?php echo notifyJs(); ?>
    <?php if (isset($component)) { $__componentOriginalf6d1e1ab7a8df2de5d0bdc28df8775f180a35b0c = $component; } ?>
<?php $component = $__env->getContainer()->make(Mckenziearts\Notify\NotifyComponent::class, []); ?>
<?php $component->withName('notify-messages'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf6d1e1ab7a8df2de5d0bdc28df8775f180a35b0c)): ?>
<?php $component = $__componentOriginalf6d1e1ab7a8df2de5d0bdc28df8775f180a35b0c; ?>
<?php unset($__componentOriginalf6d1e1ab7a8df2de5d0bdc28df8775f180a35b0c); ?>
<?php endif; ?>
</body>
</html><?php /**PATH C:\Users\brand\Documents\xampp\htdocs\SistemaGestionDocumental\resources\views/login.blade.php ENDPATH**/ ?>