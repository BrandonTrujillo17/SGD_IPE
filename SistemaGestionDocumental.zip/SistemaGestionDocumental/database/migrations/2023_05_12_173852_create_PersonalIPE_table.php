<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('PersonalIPE', function (Blueprint $table) {
            $table->string('id', 20);
            $table->string('nombre', 100);
            $table->string('usuario', 50);
            $table->string('contraseña', 50);
            $table->string('rol', 50);
            $table->string('estatus', 10)->nullable();
            $table->string('perteneceA', 150);

            $table->primary(['id'], 'PK_PersonalIPE');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('PersonalIPE');
    }
};
