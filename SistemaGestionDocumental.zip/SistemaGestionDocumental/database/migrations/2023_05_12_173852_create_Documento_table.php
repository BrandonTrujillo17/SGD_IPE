<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('Documento', function (Blueprint $table) {
            $table->increments('id');
            $table->string('numeroDocumento', 100);
            $table->string('tipoDocumento', 50);
            $table->string('asunto', 300);
            $table->integer('documentoAntecedente')->nullable();
            $table->integer('documentoPrecedente')->nullable();
            $table->string('estatusRespuesta', 5);
            $table->integer('diasRespuesta')->nullable();
            $table->string('quienResponde')->nullable();
            $table->string('comentarios', 500)->nullable();
            $table->date('fechaCreacion');
            $table->string('estatus', 50);
            $table->string('enviadoRecibido', 10);
            $table->string('noPersonalEmisor', 20)->nullable();

            $table->primary(['id'], 'PK_Documento');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('Documento');
    }
};
