<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('EnviadoA', function (Blueprint $table) {
            $table->increments('idEnvio');
            $table->string('recibido', 5)->nullable();
            $table->dateTime('fechaHoraRecepcion')->nullable();
            $table->string('tipoEnvio', 10);
            $table->string('numDocumento', 100);
            $table->string('nombreArea', 150);

            $table->primary(['idEnvio'], 'PK_EnviadoA');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('EnviadoA');
    }
};
