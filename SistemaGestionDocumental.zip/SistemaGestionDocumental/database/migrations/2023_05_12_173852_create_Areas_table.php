<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('Areas', function (Blueprint $table) {
            $table->increments('idArea');
            $table->string('nombreArea', 150);
            $table->string('tipoArea', 50)->nullable();
            $table->string('perteneceA', 150);

            $table->primary(['idArea'], 'PK_Area');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('Areas');
    }
};
