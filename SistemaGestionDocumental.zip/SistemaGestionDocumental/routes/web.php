<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\documentoController;
use App\Http\Controllers\usuarioController;
use App\Http\Controllers\areaController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('login');
});
//carga la pantalla principal de los documentos
Route::get('/principal', [documentoController::class, 'listarDocumentos']);

//carga la pantalla donde se enlistan los usuarios
Route::get('/usuarios', [usuarioController::class, 'listarUsuarios']);

//llena un select que está en el formulario de registro del usuario y muestra el formulario de registro
Route::get('/formularioRegistroUsuario', [areaController::class, 'obtenerAreasUsuario']);

//guarda la información del usuario registrado
Route::post('/registrarUsuario', [usuarioController::class, 'registrarUsuario']);

//llena el formulario de edición de un usuario
Route::get('/llenarEdicionUsuario/{id}', [usuarioController::class, 'llenarEdicionUsuario']);

//guardar la edición del usuario
Route::put('/editarUsuario/{id}', [usuarioController::class, 'editarUsuario']);

//elimina un usuario (cambia su estatus a inactivo)
Route::get('/eliminarUsuario/{id}', [usuarioController::class, 'eliminarUsuario']);

//carga la pantalla donde se enlistan las áreas
Route::get('/areas', [areaController::class, 'listarAreas']);

//llena un select que está en el formulario de registro de áreas y muestra dicho formulario
Route::get('/formularioRegistroArea', [areaController::class, 'obtenerAreas']);

//guarda la información de área registrada
Route::post('/registrarArea', [areaController::class, 'registrarArea']);

//llena el formulario de edición del área
Route::get('/llenarEdicionArea/{id}', [areaController::class, 'llenarEdicionArea']);

//guarda la información actualizada del área
Route::put('/editarArea/{id}', [areaController::class, 'editarArea']);

//cambia a inactivo el estatus de un área para que ya no se muestre al usuario
Route::get('/eliminarArea/{id}', [areaController::class, 'eliminarArea']);

//llena y muestra la ventana de registrar documento enviado
Route::get('/cargarRegistrarDocumentoEnviado', [areaController::class, 'obtenerAreasRegistrarDocumentoEnviado']);

//guarda la información de un nuevo documento enviado
Route::post('/registrarDocumentoEnviado', [documentoController::class, 'registrarDocumentoEnviado']);

//llena y muestra la ventana de registrar documento recibido
Route::get('/cargarRegistrarDocumentoRecibido', [areaController::class, 'obtenerAreasRegistrarDocumentoRecibido']);

//guarda la información de un nuevo documento recibido
Route::post('/registrarDocumentoRecibido', [documentoController::class, 'registrarDocumentoRecibido']);

//llena el detalle de documento enviado
Route::get('/verDetalleDocumentoEnviado/{id}', [documentoController::class, 'verDetalleDocumentoEnviado']);

Route::put('/guardarCambiosDetalleDocumentoEnviado/{id}', [documentoController::class, 'guardarCambiosDetalleDocumentoEnviado']);

Route::put('/guardarRecepcionEnvio/{numeroDocumento}', [documentoController::class, 'guardarRecepcionEnvio']);

Route::get('/verDetalleDocumentoRecibido/{id}', [documentoController::class, 'verDetalleDocumentoRecibido']);
