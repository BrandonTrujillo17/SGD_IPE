<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\registroAreaRequest;
use App\Models\Area;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Log;
use DB;

class areaController extends Controller
{
    //
    public function obtenerAreasUsuario(Request $request){
        try {
            $areas=DB::table('dbo.Areas')
            ->where('estatus', '=', 'Activo')
            ->orderby('tipoArea', 'asc')
            ->orderby('nombreArea', 'asc')
            ->get();
            return view ('registrarUsuario', ['areas'=>$areas]);
        } catch (\Exception $ex) {
            
        }
        
    }

    public function obtenerAreas(Request $request){
        try {
            $areas=DB::table('dbo.Areas')
            ->where('estatus', '=', 'Activo')
            ->orderby('tipoArea', 'asc')
            ->orderby('nombreArea', 'asc')
            ->get();
            return view ('registrarArea', ['areas'=>$areas]);
        } catch (\Exception $ex) {
            Log::debug($ex->getMessage());
            notify()->error('Ocurrió un error al cargar la información, intente más tarde');
            return Redirect::to('areas');
        }
        
    }

    public function listarAreas(){
        try {
            $areas=DB::table('dbo.Areas')
            ->where('estatus', '=', 'Activo')
            ->orderby('tipoArea', 'asc')
            ->orderby('nombreArea', 'asc')
            ->get();
            return view ('areas', ['areas'=>$areas]);
        } catch (\Exception $ex) {
            Log::debug($ex->getMessage());
            notify()->error('Ocurrió un error al cargar la información correspondiente a las áreas, intente más tarde');
            return Redirect::to('usuarios');
        }
        
    }

    public function obtenerAreasRegistrarDocumentoEnviado(){
        try {
            $areas=DB::table('dbo.Areas')
            ->where('estatus', '=', 'Activo')
            ->orderby('tipoArea', 'asc')
            ->orderby('nombreArea', 'asc')
            ->get();
            return view ('registrarDocumentoEnviado', ['areas'=>$areas]);
        } catch (\Exception $ex) {
            Log::debug($ex->getMessage());
            notify()->error('Ocurrió un error al cargar la información, intente más tarde');
            return Redirect::to('principal');
        }
        
    }

    public function obtenerAreasRegistrarDocumentoRecibido(){
        try {
            $areas=DB::table('dbo.Areas')
            ->where('estatus', '=', 'Activo')
            ->orderby('tipoArea', 'asc')
            ->orderby('nombreArea', 'asc')
            ->get();
            return view ('registrarDocumentoRecibido', ['areas'=>$areas]);
        } catch (\Exception $ex) {
            Log::debug($ex->getMessage());
            notify()->error('Ocurrió un error al cargar la información, intente más tarde');
            return Redirect::to('principal');
        }
        
    }

    public function registrarArea(RegistroAreaRequest $requestArea){
        try {
            $area = new Area;
            $area->nombreArea = $requestArea->get('nombreArea');
            $area->tipoArea = $requestArea->get('tipoArea');
            $area->perteneceA = $requestArea->get('perteneceA');
            $area->estatus = 'Activo';
            $area->save();
            notify()->success('Área agregada exitosamente');
            return Redirect::to('areas');
        } catch (\Exception $ex) {
            Log::debug($ex->getMessage());
            notify()->error('Ocurrió un error al realizar el registro, intente más tarde');
            return Redirect::to('principal');
        } 
    }

    public function llenarEdicionArea($id){
        try {
            $areas=DB::table('dbo.Areas')
            ->where('estatus', '=', 'Activo')
            ->orderby('tipoArea', 'asc')
            ->orderby('nombreArea', 'asc')
            ->get();

            $informacionArea = Area::FindOrfail($id);
            return view ('editarArea', 
            [
                'informacionArea'=>$informacionArea,
                'areas'=>$areas
            ]);
        } catch (\Exception $ex) {
            Log::debug($ex->getMessage());
            notify()->error('Ocurrió un error al cargar la información, intente más tarde');
            return Redirect::to('areas');
        }
        
    }



    public function editarArea(RegistroAreaRequest $requestAreaEdicion, $id){
        try {
            $area = Area::FindOrfail($id);
            $area->nombreArea = $requestAreaEdicion->get('nombreArea');
            $area->tipoArea = $requestAreaEdicion->get('tipoArea');
            $area->perteneceA = $requestAreaEdicion->get('perteneceA');
            $area->save();
            notify()->success('Área actualizada exitosamente');
            return Redirect::to('areas');
        } catch (\Exception $ex) {
            Log::debug($ex->getMessage());
            notify()->error('Ocurrió un error al realizar la actualización, intente más tarde');
            return Redirect::to('areas');
        }
        
    }

    public function eliminarArea($id){
        try {
            $area = Area::FindOrfail($id);
            $area->estatus = 'Inactivo';
            $area->update();
            notify()->success('Área eliminada exitosamente');
            return Redirect::to('areas');
        } catch (\Exception $ex) {
            Log::debug($ex->getMessage());
            notify()->error('Ocurrió un error al realizar la eliminación, intente más tarde');
            return Redirect::to('areas');
        }
        
    }
}
