<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\registroDocumentoEnviadoRequest;
use App\Http\Requests\registroEnviadoARequest;
use App\Models\Documento;
use App\Models\EnviadoA;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;
use DB;
class documentoController extends Controller
{
    
    public function listarDocumentos(){
        try {
            $enviado=DB::table('dbo.Documento')
            ->where('enviadoRecibido', '=', 'enviado')
            ->get();
            $recibido=DB::table('dbo.Documento')
            ->where('enviadoRecibido', '=', 'recibido')
            ->get();

            return view('principalPersonalIPE', 
            [
                'enviado'=>$enviado, 
                'recibido'=>$recibido
            ]);
        } catch (\Exception $ex) {
            Log::debug($ex->getMessage());
            notify()->error('Ocurrió un error al cargar la información, intente más tarde');
            return Redirect::to('/');
        }
        
    }

    public function registrarDocumentoEnviado(registroDocumentoEnviadoRequest $requestDocumento, registroEnviadoARequest $requestEnviadoA){
        DB::beginTransaction();
        try {
            if(isset($requestEnviadoA->checkEnviado) && isset($requestEnviadoA->checkCopia)){
                if($requestDocumento->get('tipoDocumento') != null && $requestDocumento->get('estatusRespuesta') != null){
                    $documento = new Documento;
                    $documento->numeroDocumento = $requestDocumento->get('numeroDocumento');
                    $documento->tipoDocumento = $requestDocumento->get('tipoDocumento');
                    $documento->asunto = $requestDocumento->get('asunto');
                    $documento->documentoAntecedente = $requestDocumento->get('documentoAntecedente');
                    $documento->documentoPrecedente = $requestDocumento->get('documentoPrecedente');
                    $documento->estatusRespuesta = $requestDocumento->get('estatusRespuesta');
                    $documento->diasRespuesta = $requestDocumento->get('diasRespuesta');
                    $documento->quienResponde = $requestDocumento->get('quienResponde');
                    $documento->comentarios = $requestDocumento->get('comentarios');
                    $documento->fechaCreacion = $requestDocumento->get('fechaCreacion');
                    $documento->estatus = 'Enviado';
                    $documento->enviadoRecibido = 'enviado';
                    $documento->save();
                    
                    foreach($requestEnviadoA->checkEnviado as $key=>$name){
                        $enviadoA = new EnviadoA;
                        $enviadoA->tipoEnvio = 'envio';
                        $enviadoA->numDocumento = $requestDocumento->get('numeroDocumento');
                        $enviadoA->nombreArea = $requestEnviadoA->checkEnviado[$key];
                        $enviadoA->save();
                    }
                    
                    foreach($requestEnviadoA->checkCopia as $key=>$name){
                        $enviadoA = new EnviadoA;
                        $enviadoA->tipoEnvio = 'copia';
                        $enviadoA->numDocumento = $requestDocumento->get('numeroDocumento');
                        $enviadoA->nombreArea = $requestEnviadoA->checkCopia[$key];
                        $enviadoA->save();
                    }
                    DB::commit(); 
                    notify()->success('Documento agregado exitosamente');
                    return Redirect::to('principal');
                }else{
                    notify()->warning('Seleccione un tipo de documento y si requiere o no una respuesta');
                    return Redirect::to('cargarRegistrarDocumentoEnviado');
                }
            }else{
                notify()->warning('Seleccione un área de envío y copia');
                return Redirect::to('cargarRegistrarDocumentoEnviado');
            }
        } catch (\Exception $ex) {
            DB::rollback();
            Log::debug($ex->getMessage());
            notify()->error('Ocurrió un error al realizar el registro, intente más tarde');
            return Redirect::to('cargarRegistrarDocumentoEnviado');
        }
                
    }

    public function registrarDocumentoRecibido(registroDocumentoEnviadoRequest $requestDocumentoRecibido, registroEnviadoARequest $requestEnviadoARecibido){
        DB::beginTransaction();
        try {
            if(isset($requestEnviadoARecibido->checkEnviado) && isset($requestEnviadoARecibido->checkCopia)){
                if($requestDocumentoRecibido->get('tipoDocumento') != null && $requestDocumentoRecibido->get('estatusRespuesta') != null){
                    $documento = new Documento;
                    $documento->numeroDocumento = $requestDocumentoRecibido->get('numeroDocumento');
                    $documento->tipoDocumento = $requestDocumentoRecibido->get('tipoDocumento');
                    $documento->asunto = $requestDocumentoRecibido->get('asunto');
                    $documento->documentoAntecedente = $requestDocumentoRecibido->get('documentoAntecedente');
                    $documento->documentoPrecedente = $requestDocumentoRecibido->get('documentoPrecedente');
                    $documento->estatusRespuesta = $requestDocumentoRecibido->get('estatusRespuesta');
                    $documento->diasRespuesta = $requestDocumentoRecibido->get('diasRespuesta');
                    $documento->quienResponde = $requestDocumentoRecibido->get('quienResponde');
                    $documento->comentarios = $requestDocumentoRecibido->get('comentarios');
                    $documento->fechaCreacion = $requestDocumentoRecibido->get('fechaCreacion');
                    $documento->estatus = 'Enviado';
                    $documento->enviadoRecibido = 'recibido';
                    $documento->save();
                    
                    foreach($requestEnviadoARecibido->checkEnviado as $key=>$name){
                        $enviadoA = new EnviadoA;
                        $enviadoA->tipoEnvio = 'envio';
                        $enviadoA->numDocumento = $requestDocumentoRecibido->get('numeroDocumento');
                        $enviadoA->nombreArea = $requestEnviadoARecibido->checkEnviado[$key];
                        $enviadoA->save();
                    }
                    
                    foreach($requestEnviadoARecibido->checkCopia as $key=>$name){
                        $enviadoA = new EnviadoA;
                        $enviadoA->tipoEnvio = 'copia';
                        $enviadoA->numDocumento = $requestDocumentoRecibido->get('numeroDocumento');
                        $enviadoA->nombreArea = $requestEnviadoARecibido->checkCopia[$key];
                        $enviadoA->save();
                    }
                    DB::commit();
                    notify()->success('Documento agregado exitosamente');
                    return Redirect::to('principal');
                }else{
                    notify()->warning('Seleccione un tipo de documento y si requiere o no una respuesta');
                    return Redirect::to('cargarRegistrarDocumentoRecibido');
                }
            }else{
                notify()->warning('Seleccione un área de envío y copia');
                return Redirect::to('cargarRegistrarDocumentoRecibido');
            }
        }catch(\Exception $ex) {
            DB::rollback();
            Log::debug($ex->getMessage());
            notify()->error('Ocurrió un error al realizar el registro, intente más tarde');
            return Redirect::to('cargarRegistrarDocumentoRecibido');
        }
    }

    public function verDetalleDocumentoEnviado($id){
        try {
            $informacionDocumento = Documento::FindOrfail($id);
            $informacionEnvio = DB::table('EnviadoA')
            ->where('numDocumento', '=', $informacionDocumento->numeroDocumento)
            ->where('tipoEnvio', '=', 'envio')
            ->get();
            $informacionCopia = DB::table('EnviadoA')
            ->where('numDocumento', '=', $informacionDocumento->numeroDocumento)
            ->where('tipoEnvio', '=', 'copia')
            ->get();

            return view('detalleDocumentoEnviado', 
            [
                'informacionDocumento'=>$informacionDocumento, 
                'informacionEnvio'=>$informacionEnvio,
                'informacionCopia'=>$informacionCopia
            ]);
        } catch (\Exeption $ex) {
            Log::debug($ex->getMessage());
            notify()->error('Ocurrió un error al cargar la información, intente más tarde');
            return Redirect::to('principal');
        }
    }

    public function verDetalleDocumentoRecibido($id){
        try {
            $informacionDocumento = Documento::FindOrfail($id);
            $informacionEnvio = DB::table('EnviadoA')
            ->where('numDocumento', '=', $informacionDocumento->numeroDocumento)
            ->where('tipoEnvio', '=', 'envio')
            ->get();
            $informacionCopia = DB::table('EnviadoA')
            ->where('numDocumento', '=', $informacionDocumento->numeroDocumento)
            ->where('tipoEnvio', '=', 'copia')
            ->get();

            return view('detalleDocumentoRecibido', 
            [
                'informacionDocumento'=>$informacionDocumento, 
                'informacionEnvio'=>$informacionEnvio,
                'informacionCopia'=>$informacionCopia
            ]);
        } catch (\Exeption $ex) {
            Log::debug($ex->getMessage());
            notify()->error('Ocurrió un error al cargar la información, intente más tarde');
            return Redirect::to('principal');
        }
    }

    public function guardarCambiosDetalleDocumentoEnviado(registroDocumentoEnviadoRequest $requestCambiosDocumentoEnviado, registroEnviadoARequest $requestCambiosEnviadA, $id){
        DB::beginTransaction();
        try {
            $cambiosDocumentoEnviado = Documento::find($id);
            $cambiosDocumentoEnviado->comentarios = $requestCambiosDocumentoEnviado->get('comentarios');
            $cambiosDocumentoEnviado->diasRespuesta = $requestCambiosDocumentoEnviado->get('diasRespuesta');
            $cambiosDocumentoEnviado->quienResponde = $requestCambiosDocumentoEnviado->get('quienResponde');
            $cambiosDocumentoEnviado->estatus = $requestCambiosDocumentoEnviado->get('estatus');
            $cambiosDocumentoEnviado->save();

            if(isset($requestCambiosEnviadA->checkRespuestaEnviado)){
                foreach ($requestCambiosEnviadA->checkRespuestaEnviado as $key => $value) {
                    $recibido = 'Sí';
                    $fechaRecepcion = Carbon::now();
                    $fechaRecepcion = $fechaRecepcion->toDateTimeString();
                    $nombreArea = $requestCambiosEnviadA->checkRespuestaEnviado[$key];
                    $numDocumento = $requestCambiosDocumentoEnviado->get('numeroDocumento');
                    $tipoEnvio = 'envio';
                    DB::update('update EnviadoA set recibido=?, fechaHoraRecepcion=? where nombreArea=? and numDocumento=? and tipoEnvio=?', [$recibido, $fechaRecepcion, $nombreArea, $numDocumento, $tipoEnvio]);
                }
            }

            if(isset($requestCambiosEnviadA->checkRespuestaCopia)){
                foreach ($requestCambiosEnviadA->checkRespuestaCopia as $key => $value) {
                    $recibido = 'Sí';
                    $fechaRecepcion = Carbon::now();
                    $fechaRecepcion = $fechaRecepcion->toDateTimeString();
                    $nombreArea = $requestCambiosEnviadA->checkRespuestaCopia[$key];
                    $numDocumento = $requestCambiosDocumentoEnviado->get('numeroDocumento');
                    $tipoEnvio = 'copia';
                    DB::update('update EnviadoA set recibido=?, fechaHoraRecepcion=? where nombreArea=? and numDocumento=? and tipoEnvio=?', [$recibido, $fechaRecepcion, $nombreArea, $numDocumento, $tipoEnvio]);
                }
            }
            DB::commit();
            notify()->success('Cambios guardados exitosamente');
            return Redirect::to('principal');
        } catch (\Exception $ex) {
            DB::rollback();
            Log::debug($ex->getMessage());
            notify()->error('Ocurrió un error al guardar la información, intente más tarde');
            return Redirect::to('principal');
        }
    }

}
