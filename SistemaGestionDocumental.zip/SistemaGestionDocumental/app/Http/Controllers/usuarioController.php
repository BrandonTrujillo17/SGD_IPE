<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
    use App\Http\Requests\registroUsuarioRequest;
use App\Models\PersonalIPE;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Log;
use DB;
class usuarioController extends Controller
{
    public function listarUsuarios(){
        try {
            $usuario=DB::table('dbo.PersonalIPE')
            ->where('estatus', '=', 'Activo')
            ->orderby('nombre', 'asc')
            ->get();

            return view('usuarios', ['usuario'=>$usuario]);
        } catch (\Exception $ex) {
            Log::debug($ex->getMessage());
            notify()->error('Ocurrió un error al cargar la información, intente más tarde');
            return Redirect::to('/');
        }
        
    }

    public function registrarUsuario(RegistroUsuarioRequest $requestUsuario){
        try {
            if($requestUsuario->get('rol') != null && $requestUsuario->get('perteneceA') != null){
                $usuario = new PersonalIPE;
                $usuario->numeroPersonal = $requestUsuario->get('noPersonal');
                $usuario->nombre = $requestUsuario->get('nombre');
                $usuario->usuario = $requestUsuario->get('usuario');
                $usuario->contraseña = $requestUsuario->get('contraseña');
                $usuario->rol = $requestUsuario->get('rol');
                $usuario->estatus = "Activo";
                $usuario->perteneceA = $requestUsuario->get('perteneceA');
                $usuario->save();
                notify()->success('Usuario creado exitosamente');
                return Redirect::to('usuarios');
            }else{
                notify()->warning('Seleccione el rol y a que área pertenece');
                return Redirect::to('formularioRegistroUsuario');
            }
            
        } catch (\Exception $ex) {
            Log::debug($ex->getMessage());
            notify()->error('Ocurrió un error al realizar el registro, intente más tarde');
            return Redirect::to('usuarios');
        }
        
    }

    public function llenarEdicionUsuario($id){
        try {
            $areas=DB::table('dbo.Areas')
            ->where('estatus', '=', 'Activo')
            ->orderby('tipoArea', 'asc')
            ->orderby('nombreArea', 'asc')
            ->get();

            $informacionUsuario = PersonalIPE::FindOrfail($id);
            return view ('editarUsuario', 
            [
                'informacionUsuario'=>$informacionUsuario,
                'areas'=>$areas
            ]);
        } catch (\Exception $ex) {
            Log::debug($ex->getMessage());
            notify()->error('Ocurrió un error al cargar la información, intente más tarde');
            return Redirect::to('usuarios');
        }
    }

    public function editarUsuario(registroUsuarioRequest $requestEdicion, $id){
        try {
            $usuario = PersonalIPE::findOrfail($id);
            $usuario->numeroPersonal = $requestEdicion->get('noPersonal');
            $usuario->nombre = $requestEdicion->get('nombre');
            $usuario->usuario = $requestEdicion->get('usuario');
            $usuario->contraseña = $requestEdicion->get('contraseña');
            $usuario->rol = $requestEdicion->get('rol');
            $usuario->perteneceA = $requestEdicion->get('perteneceA');
            $usuario->save();
            notify()->success('Usuario actualizado exitosamente');
            return Redirect::to('usuarios');
        } catch (\Exception $ex) {
            Log::debug($ex->getMessage());
            notify()->error('Ocurrió un error al realizar la edición, intente más tarde');
            return Redirect::to('usuarios');
        }
        
    }

    public function eliminarUsuario($id){
        try {
            $usuario = PersonalIPE::findOrfail($id);
            $usuario->estatus='Inactivo';
            $usuario->update();
            notify()->success('Usuario eliminado exitosamente');
            return Redirect::to('usuarios');
        } catch (\Exception $ex) {
            Log::debug($ex->getMessage());
            notify()->error('Ocurrió un error al realizar la eliminación, intente más tarde');
            return Redirect::to('usuarios');
        }
       
    }
}
