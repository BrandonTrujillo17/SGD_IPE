<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PersonalIPE extends Model
{
    //use HasFactory;
    public $timestamps=false;
    protected $table = 'PersonalIPE';
    protected $fillable = [
        'id',
        'numeroPersonal',
        'nombre',
        'usuario',
        'contraseña',
        'rol',
        'estatus',
        'perteneceA'
    ];
}
