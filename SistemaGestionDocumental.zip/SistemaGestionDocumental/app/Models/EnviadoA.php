<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EnviadoA extends Model
{
    //use HasFactory;
    public $timestamps=false;
    protected $table = 'EnviadoA';
    protected $fillable = [
        'idEnvio',
        'recibido',
        'fechaHoraRecepcion',
        'tipoEnvio',
        'numDocumento',
        'nombreArea'
    ];
}
