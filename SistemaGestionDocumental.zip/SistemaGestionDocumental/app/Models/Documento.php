<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Documento extends Model
{
    //use HasFactory;
    public $timestamps=false;
    protected $table='Documento';
    protected $fillable=[
        'id',
        'numeroDocumento',
        'tipoDocumento',
        'asunto',
        'documentoAntecedente',
        'documentoPrecedente',
        'estatusRespuesta',
        'diasRespuesta',
        'quienResponde',
        'comentarios',
        'fechaCreacion',
        'estatus',
        'enviadoRecibido',
        'noPersonalEmisor'
    ];
}
